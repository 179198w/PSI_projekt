Impreza turystyczna ma miejsce tylko w jednym kraju, w jednym mieście i jednym hotelu - nie możliwości tworzenia wycieczek objazdowych.
Najważniejsze prototypy:
1. p3_dodawanie_edycja_imprezy
2. p2_wyszukanie_imprez
3. p12_dodawanie_terminu
4. p13_edycja_terminu
5. p21_dodawanie_edycja_cenniku
6. p23_wyszukanie_imprez_przez_klienta
7. p24_podglad_imprezy_klient
8. p25_rezerwacja_imprezy
9. p9_dodawanie_edycja_katalogu
10. p11_wyszukanie_terminow

Idea:
Organizator tworzy impreze - szablon ze składnikami. Do wycieczki przypisuje terminy, w których impreza się odbywa.
Dla danej wycieczki i jej wybranych terminów tworzy cennik, gdzie definiuje cenę bazową oraz ceny kolejnych składników.
W różnych terminach imprezy cena bazowa jak i ceny składników mogą być różne.